<?php

namespace App\Models;

use App\Models\Concerns\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ExamSchedule extends Model
{
    use BelongsToTenant;
    protected $fillable = [
        'exam_id',
        'subject_id',
        'branch_id',
        'grade',
        'section',
        'exam_date',
        'start_time',
        'end_time',
        'duration',
        'total_marks',
        'passing_marks',
        'room_number',
        'invigilator_id',
        'instructions'
    ];

    protected function casts(): array
    {
        return [
            'exam_date' => 'date',
            'total_marks' => 'decimal:2',
        ];
    }

    // Relationships
    public function exam(): BelongsTo
    {
        return $this->belongsTo(Exam::class);
    }

    public function subject(): BelongsTo
    {
        return $this->belongsTo(Subject::class);
    }

    public function invigilator(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'invigilator_id');
    }
}

