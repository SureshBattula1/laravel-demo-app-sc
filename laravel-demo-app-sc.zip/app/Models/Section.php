<?php

namespace App\Models;

use App\Models\Concerns\BelongsToTenant;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class Section extends Model
{
    use BelongsToTenant;
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'branch_id',
        'school_id',
        'name',
        'code',
        'grade_level',
        'capacity',
        'current_strength',
        'room_number',
        'class_teacher_id',
        'description',
        'is_active'
    ];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
            'capacity' => 'integer',
            'current_strength' => 'integer',
        ];
    }

    /**
     * Attributes to append to JSON
     */
    protected $appends = ['grade_label', 'actual_strength'];

    /**
     * Preloaded grade row, injected by list endpoints to avoid an N+1 in the
     * grade_label / grade_details accessors (which both resolve the grade).
     * Declared as a real PHP property so it is NOT serialized into JSON.
     */
    public ?object $preloadedGrade = null;
    public bool $gradePreloaded = false;

    /**
     * Inject a pre-fetched grade row (from a single batch query) so the
     * accessors don't each hit the DB per row.
     */
    public function setPreloadedGrade(?object $grade): void
    {
        $this->preloadedGrade = $grade;
        $this->gradePreloaded = true;
    }

    /**
     * Resolve grade from grades table (branch-specific join by branch_id + value).
     * Uses the preloaded grade when the caller has batch-loaded it (avoids N+1).
     */
    private function resolveGradeFromGradesTable(): ?object
    {
        if (!$this->grade_level) {
            return null;
        }
        if ($this->gradePreloaded) {
            return $this->preloadedGrade;
        }
        return DB::table('grades')
            ->where('branch_id', $this->branch_id)
            ->where('value', $this->grade_level)
            ->first();
    }

    /**
     * Get grade label (e.g., "International Grade 10" instead of "10")
     * Joins grades by branch_id + value so branch-specific labels (e.g. "International Grade 10") display correctly.
     */
    public function getGradeLabelAttribute(): ?string
    {
        if ($this->grade_level) {
            $grade = $this->resolveGradeFromGradesTable();
            if ($grade) {
                return $grade->label;
            }
            return 'Grade ' . $this->grade_level;
        }
        return 'All Grades';
    }

    /**
     * Get full grade details
     */
    public function getGradeDetailsAttribute(): ?array
    {
        if ($this->grade_level) {
            $grade = $this->resolveGradeFromGradesTable();
            if ($grade) {
                return [
                    'value' => $grade->value,
                    'label' => $grade->label,
                    'description' => $grade->description ?? null,
                    'is_active' => (bool) $grade->is_active
                ];
            }
            // Fallback if grade not found in grades table
            return [
                'value' => $this->grade_level,
                'label' => 'Grade ' . $this->grade_level,
                'description' => null,
                'is_active' => true
            ];
        }
        return null;
    }

    // Relationships
    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function school()
    {
        return $this->belongsTo(School::class);
    }

    public function classTeacher()
    {
        return $this->belongsTo(User::class, 'class_teacher_id');
    }

    /**
     * Get actual student strength by counting students in this section
     */
    public function getActualStrengthAttribute(): int
    {
        return DB::table('students')
            ->where('branch_id', $this->branch_id)
            ->where('grade', $this->grade_level)
            ->where('section', $this->name)
            ->where('student_status', 'Active')
            ->count();
    }

    public function students()
    {
        // Note: This relationship won't work with current schema where students have grade/section as strings
        // Use the actualStrength accessor instead
        return $this->hasMany(User::class, 'section_id')->where('user_type', 'Student');
    }

    /**
     * Get associated class (if exists)
     */
    public function class()
    {
        return $this->hasOne(\App\Models\ClassModel::class, 'section', 'name')
            ->where('grade', $this->grade_level)
            ->where('branch_id', $this->branch_id);
    }

    /**
     * Get subjects assigned to this section
     */
    public function subjects()
    {
        return $this->belongsToMany(
            Subject::class,
            'section_subjects',
            'section_id',
            'subject_id'
        )
        ->withPivot(['teacher_id', 'academic_year', 'is_active'])
        ->withTimestamps();
    }

    /**
     * Get section subjects with full details
     */
    public function sectionSubjects()
    {
        return $this->hasMany(SectionSubject::class);
    }

    // Helper methods
    public function getAvailableSeats()
    {
        return $this->capacity - $this->current_strength;
    }

    public function isFull()
    {
        return $this->current_strength >= $this->capacity;
    }

    // Scopes
    public function scopeForSchool($query, int $schoolId)
    {
        return $query->where('school_id', $schoolId);
    }
}

