<?php

namespace App\Http\Controllers;

use App\Http\Traits\PaginatesAndSorts;
use App\Models\FeeType;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Validation\Rule;

class FeeTypeController extends Controller
{
    use PaginatesAndSorts;

    /**
     * Display a listing of fee types with server-side pagination
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $query = FeeType::with(['branch', 'academicYear']);

            // Apply school filtering - show only fee types for the current school
            $schoolId = $this->getCurrentSchoolId($request);
            if ($schoolId) {
                $query->where('school_id', $schoolId);
            }

            // Apply branch filtering - restrict to accessible branches
            $accessibleBranchIds = $this->getAccessibleBranchIds($request);
            if ($accessibleBranchIds !== 'all') {
                if (!empty($accessibleBranchIds)) {
                    $query->whereIn('branch_id', $accessibleBranchIds);
                } else {
                    $query->whereRaw('1 = 0');
                }
            }

            // Filter by specific branch when provided
            if ($request->has('branch_id') && $request->branch_id) {
                $query->where('branch_id', $request->branch_id);
            }

            // Filter by academic year when provided
            if ($request->has('academic_year_id') && $request->academic_year_id) {
                $query->where('academic_year_id', $request->academic_year_id);
            }

            // Filter by active status
            if ($request->has('is_active')) {
                $query->where('is_active', filter_var($request->is_active, FILTER_VALIDATE_BOOLEAN));
            }

            // OPTIMIZED Search filter - prefix search for better index usage
            if ($request->has('search') && !empty($request->search)) {
                $search = strip_tags($request->search);
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', "{$search}%")
                      ->orWhere('code', 'like', "{$search}%")
                      ->orWhere('description', 'like', "{$search}%");
                });
            }

            // Filter by mandatory status
            if ($request->has('is_mandatory')) {
                $query->where('is_mandatory', filter_var($request->is_mandatory, FILTER_VALIDATE_BOOLEAN));
            }

            // Define sortable columns
            $sortableColumns = ['id', 'name', 'code', 'is_active', 'is_mandatory', 'is_refundable', 'created_at'];

            // Apply pagination and sorting (default: 25 per page, sorted by name asc)
            $feeTypes = $this->paginateAndSort($query, $request, $sortableColumns, 'name', 'asc');

            // Return standardized paginated response
            return response()->json([
                'success' => true,
                'message' => 'Fee types retrieved successfully',
                'data' => $feeTypes->items(),
                'meta' => [
                    'current_page' => $feeTypes->currentPage(),
                    'per_page' => $feeTypes->perPage(),
                    'total' => $feeTypes->total(),
                    'last_page' => $feeTypes->lastPage(),
                    'from' => $feeTypes->firstItem(),
                    'to' => $feeTypes->lastItem(),
                    'has_more_pages' => $feeTypes->hasMorePages()
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve fee types: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created fee type
     */
    public function store(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'code' => 'required|string|max:50|unique:fee_types,code',
                'description' => 'nullable|string',
                'branch_id' => 'required|exists:branches,id',
                'academic_year_id' => 'required|exists:academic_years,id',
                'is_mandatory' => 'boolean',
                'is_refundable' => 'boolean',
                'is_active' => 'boolean',
            ]);

            $branch = \App\Models\Branch::find($validated['branch_id']);
            $validated['school_id'] = $branch ? $branch->school_id : null;
            $feeType = FeeType::create($validated);
            $feeType->load(['branch', 'academicYear']);

            return response()->json([
                'success' => true,
                'message' => 'Fee type created successfully',
                'data' => $feeType
            ], 201);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create fee type: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Display the specified fee type
     */
    public function show(string $id): JsonResponse
    {
        try {
            $feeType = FeeType::with(['branch', 'academicYear'])->findOrFail($id);

            return response()->json([
                'success' => true,
                'message' => 'Fee type retrieved successfully',
                'data' => $feeType
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Fee type not found'
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve fee type: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update the specified fee type
     */
    public function update(Request $request, string $id): JsonResponse
    {
        try {
            $feeType = FeeType::findOrFail($id);

            $validated = $request->validate([
                'name' => 'sometimes|required|string|max:255',
                'code' => [
                    'sometimes',
                    'required',
                    'string',
                    'max:50',
                    Rule::unique('fee_types', 'code')->ignore($feeType->id)
                ],
                'description' => 'nullable|string',
                'branch_id' => 'sometimes|required|exists:branches,id',
                'academic_year_id' => 'sometimes|required|exists:academic_years,id',
                'is_mandatory' => 'boolean',
                'is_refundable' => 'boolean',
                'is_active' => 'boolean',
            ]);

            $feeType->update($validated);
            $feeType->load(['branch', 'academicYear']);

            return response()->json([
                'success' => true,
                'message' => 'Fee type updated successfully',
                'data' => $feeType
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Fee type not found'
            ], 404);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update fee type: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Remove the specified fee type
     */
    public function destroy(string $id): JsonResponse
    {
        try {
            $feeType = FeeType::findOrFail($id);

            // Check if fee type is being used in fee structures (by name match)
            $structureCount = \App\Models\FeeStructure::where('fee_type', $feeType->name)->count();
            if ($structureCount > 0) {
                return response()->json([
                    'success' => false,
                    'message' => "Cannot delete fee type. It is being used in {$structureCount} fee structure(s)."
                ], 422);
            }

            $feeType->delete();

            return response()->json([
                'success' => true,
                'message' => 'Fee type deleted successfully'
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Fee type not found'
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete fee type: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Toggle fee type active status
     */
    public function toggleStatus(string $id): JsonResponse
    {
        try {
            $feeType = FeeType::findOrFail($id);
            // Use deterministic 0/1 toggle to avoid truthy string edge-cases.
            $feeType->is_active = ((int) $feeType->is_active) === 1 ? 0 : 1;
            $feeType->save();
            $feeType->load(['branch', 'academicYear']);

            return response()->json([
                'success' => true,
                'message' => 'Fee type status updated successfully',
                'data' => $feeType
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Fee type not found'
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to toggle status: ' . $e->getMessage()
            ], 500);
        }
    }
}

