<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('departments', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('head');
            $table->foreignId('head_id')->nullable()->constrained('users')->onDelete('set null');
            $table->text('description')->nullable();
            $table->date('established_date')->nullable();
            $table->foreignId('branch_id')->constrained('branches')->onDelete('cascade');
            $table->integer('students_count')->default(0);
            $table->integer('teachers_count')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('departments');
    }
};
